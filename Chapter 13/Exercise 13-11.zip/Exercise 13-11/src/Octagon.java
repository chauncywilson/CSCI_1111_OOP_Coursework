/*
Chauncy Wilson, Object-Oriented Programming 1

10/27/22, Octagon with compare/clone interfaces
 */

import java.util.Scanner;

public class Octagon extends GeometricObject implements Cloneable, Comparable<Octagon>{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Octagon octagon = new Octagon();
        System.out.println("Area = " + octagon.area);
        System.out.println("Perimeter = " + octagon.perimeter);
        System.out.println("Color = " + octagon.color);
        System.out.println("Filled = " + octagon.filled);

        System.out.print("\nDo you wish to clone? ");
        if (input.nextLine().equalsIgnoreCase("y")){
            Octagon octagon1 = octagon.clone();
            System.out.println("octagon.compareTo(clone) = " + octagon.compareTo(octagon1));
        }
    }

    double side;
    double area;
    double perimeter;
    String color;
    boolean filled;

    Octagon(){
        getSide();
        getColor();
        isFilled();
        getArea();
        getPerimeter();
    }

    public void getSide() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the length of the sides: ");
        side = input.nextDouble();
    }

    @Override
    double getArea(){
        area = ((2 + (4 / Math.sqrt(2))) * side * side);
        return area;
    }

    @Override
    double getPerimeter(){
        perimeter = side * 8;
        return perimeter;
    }

    @Override
    String getColor(){
        Scanner input = new Scanner(System.in);
        System.out.print("\nPlease enter a color: ");
        color = input.nextLine();
        return color;
    }

    @Override
    boolean isFilled(){
        Scanner input = new Scanner(System.in);
        filled = true;
        System.out.print("\nIs the shape filled? 'Y' or 'N': ");
        String choice = input.nextLine();
        if (choice.equalsIgnoreCase("n")){
            filled = false;
        }
        return filled;
    }

    @Override
    public int compareTo(Octagon o) {
        if (area > o.area) return 1;
        else if (area < o.area) return -1;
        else return 0;
    }

    @Override
    public Octagon clone() {
        try {
            Octagon octagon1 = (Octagon) super.clone();
            return octagon1;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
