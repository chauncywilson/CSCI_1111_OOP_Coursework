/*
Chauncy Wilson, Object-Oriented Programming 1

10/27/22, Octagon with compare/clone interfaces
 */

public abstract class GeometricObject {

    abstract double getArea();

    abstract double getPerimeter();

    abstract String getColor();

    abstract boolean isFilled();
}
