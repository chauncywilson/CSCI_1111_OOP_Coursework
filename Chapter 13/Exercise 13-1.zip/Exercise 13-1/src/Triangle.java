/*
Chauncy Wilson, Object-Oriented Programming
10/25/22, Triangle extension/abstract overrides
 */

import java.util.Scanner;

public class Triangle extends GeometricObject{
    public static void main(String[] args) {

        new Triangle();
    }


    double side1 = 0;
    double side2 = 0;
    double side3 = 0;

    Triangle(){
        getSide1();
        getSide2();
        getSide3();
        String color = getColor();
        boolean filled = isFilled();
        System.out.println("\nArea = " + getArea());
        System.out.println("Perimeter = " + getPerimeter());
        System.out.println("Color = " + color);
        System.out.println("Filled = " + filled);
    }

    double getSide1(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the length of side 1: ");
        side1 = input.nextDouble();
        return side1;
    }

    double getSide2(){
        Scanner input = new Scanner(System.in);
        System.out.print("\nEnter the length of side 2: ");
        side2 = input.nextDouble();
        return side2;
    }

    double getSide3(){
        Scanner input = new Scanner(System.in);
        System.out.print("\nEnter the length of side 3: ");
        side3 = input.nextDouble();
        return side3;
    }

    @Override
    double getArea() {
        double s = (side1 + side3 + side3) / 2;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    @Override
    double getPerimeter() {
        return side1 + side2 + side3;
    }

    @Override
    String getColor() {
        Scanner input = new Scanner(System.in);
        System.out.print("\nPlease enter the color: ");
        return input.nextLine();
    }

    @Override
    boolean isFilled() {
        Scanner input = new Scanner(System.in);
        boolean filled = false;
        System.out.print("\nIs the shape filled? 'Y' or 'N' ");
        String line = input.nextLine();
        if (line.equalsIgnoreCase("Y")){
            filled = true;
        }
        return filled;
    }
}
