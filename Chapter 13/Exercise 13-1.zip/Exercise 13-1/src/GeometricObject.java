/*
Chauncy Wilson, Object-Oriented Programming 1
10/25/22, Abstract methods with triangles
 */

import java.util.Scanner;

public abstract class GeometricObject {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] sides = new double[3];
        int count = 0;
        while (count < 1) {
            System.out.print("Please enter the lengths of the sides in this shape separated by spaces. ");
            sides[count] = input.nextDouble();
            count++;
        }
    }


    //getArea()
    abstract double getArea();

    //getPerimeter()
    abstract double getPerimeter();

    //getColor()
    abstract String getColor();

    //isFilled()
    abstract boolean isFilled();
}
