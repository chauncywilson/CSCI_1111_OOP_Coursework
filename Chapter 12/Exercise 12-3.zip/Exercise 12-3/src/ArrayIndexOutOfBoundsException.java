/*
Chauncy Wilson, Object-Oriented Programming 1

10/18/22, Exception training with arrays
 */

import java.util.Scanner;

public class ArrayIndexOutOfBoundsException {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] array = new int[100];
        for (int count = 0; count < array.length-1; count++) {
            array[count] = (int) (Math.random() * 100);
        }

        System.out.print("Enter an integer between 1 - 100: ");

        int user = input.nextInt();
        int inputNumber = user;
        user--;
        try {
            System.out.println("\nIndex at " + inputNumber + " is " + array[user]);
        }


        catch (java.lang.ArrayIndexOutOfBoundsException exception){
            System.out.println("\nOut of Bounds");
        }
    }
}
