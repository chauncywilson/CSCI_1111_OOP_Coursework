/*
Chauncy Wilson, Object-Oriented Programming 1

10/19/22, Write and read data from self created files
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
import java.util.Scanner;

public class WriteReadData {
    public static void main(String[] args) throws IOException {

        File file = new File("Exercise12_15.txt");
        if (file.exists()) {
            System.out.println("File already exists");
            System.exit(1);
        }

        PrintWriter output = new PrintWriter(file);
        for (int count = 0; count < 100; count++) {
            output.print((int) (Math.random() * 100) + " ");
            //file creation and write data to

            if (count % 5 == 0 && count != 0) {
                output.println();
            }
        }
        output.close();

        int[] array = new int[100];

        Scanner input = new Scanner(file);
        for (int count = 0; input.hasNext(); count++) {
            array[count] = input.nextInt();
        }
        input.close();

        int temp;
        for (int count = 0, subCount = 1; count < array.length - 1;) {
            for (; subCount < array.length - 1; subCount++) {

                if (array[count] > array[subCount]) {
                    temp = array[count];
                    array[count] = array[subCount];
                    array[subCount] = temp;
                }
            }
            System.out.print(array[count] + " ");
            if (count % 10 == 0 && count != 0) {
                System.out.println();
            }
            count++;
            subCount = count + 1;
        }
    }
}
