/*
Chauncy Wilson, Object-Oriented Programming 1

10/6/22, integer identification
 */

import java.util.Scanner;

public class MyInteger {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String exit = "N";

        while (!(exit.equalsIgnoreCase("Y"))) {
            //new integer
            MyInteger integer = new MyInteger();

            if (isEven(integer.value)) {
                System.out.println(integer.value + " is an even number.");
            }
            if (isOdd(integer.value)) {
                System.out.println(integer.value + " is an odd number.");
            }
            if (isPrime(integer.value)) {
                System.out.println(integer.value + " is a prime number.");
            }

            System.out.println("\nDo you wish to continue? Y or N");
            exit = input.nextLine();

            if (exit.equalsIgnoreCase("N")){
                break;
            }
            else {
                MyInteger integer1 = new MyInteger();

                if (isEven(integer1)){
                    System.out.println(integer1.value + " is an even number.");
                }

                if (isOdd(integer1)){
                    System.out.println(integer1.value + " is an odd number.");
                }

                if (isPrime(integer1)){
                    System.out.println(integer1.value + " is a prime number.");
                }
                if (integer1.equals(integer1, integer)){
                    System.out.println(integer1.value + " equals " + integer.value);
                }
                else {
                    System.out.println(integer1.value + " doesn't equal " + integer.value);
                }
            }
        }
    }

    //Data Field
    public int value = 0;


    MyInteger() {
        if (!(getInt() > 0)){
            System.exit(1);
        }
        if (!(isEven())){
            System.out.print("");
        }
        if (!(isOdd())){
            System.out.print("");
        }
        if (!(isPrime())){
            System.out.print("");
        }
        if (equals(value, value)){
            System.out.print("");
        }
    }

    int getInt(){
        value = 0;
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter an integer: ");
        return value = input.nextInt();
    }

    boolean isEven() {
        return value % 2 == 0;
    }

    boolean isOdd() {
        return value % 2 != 0;
    }

    boolean isPrime() {
        boolean isValid = true;

        for (int first = 2, second = 2; second <= value / 2; first++){
            if (first >= value / 2){
                first = 2;
                second++;
            }
            if (first * second == value) {
                isValid = false;
                break;
                }
            }
        return isValid;
    }

    static boolean isEven(int value) {
        return value % 2 == 0;
    }

    static boolean isOdd(int value) {
        return value % 2 != 0;
    }

    static boolean isPrime(int value) {
        boolean isValid = true;
        for (int first = 2, second = 2; second <= value / 2; first++){
            if (first >= value / 2){
                first = 2;
                second++;
            }
            if (first * second == value) {
                isValid = false;
                break;
            }
        }
        return isValid;
    }

    static boolean isEven(MyInteger integer1) {
        int newValue = parseInt(String.valueOf(integer1.value));
        return newValue % 2 == 0;
    }

    static boolean isOdd(MyInteger integer1) {
        int newValue = parseInt(String.valueOf(integer1.value));
        return newValue % 2 != 0;
    }

    static boolean isPrime(MyInteger integer1) {
        int newValue = parseInt(String.valueOf(integer1.value));
        boolean isValid = true;
        for (int first = 2, second = 2; second <= newValue / 2; first++){
            if (first >= newValue / 2){
                first = 2;
                second++;
            }
            if (first * second == newValue) {
                isValid = false;
                break;
            }
        }
        return isValid;
    }

    boolean equals(int value, int oldValue){
        return value == oldValue;
    }

    boolean equals(MyInteger integer, MyInteger integer1){

        return integer.value == integer1.value;
    }

    static int parseInt(char[] integer1) {
        int newInteger1 = Integer.parseInt(String.valueOf(integer1));
        return newInteger1;
    }

    static int parseInt(String integer1) {
        int newInteger1 = Integer.parseInt(integer1);
        return newInteger1;
    }
}
