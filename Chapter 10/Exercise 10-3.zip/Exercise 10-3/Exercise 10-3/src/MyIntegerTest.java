

public class MyIntegerTest {

    @org.junit.Test
    public void testIsEven() {
        int count = 1;
        while (count != 10){
            if (MyInteger.isEven(count)){
                System.out.println("True");
            }
            else {
                System.out.println("False");
            }
            count++;
        }
    }

    @org.junit.Test
    public void testIsOdd() {
        int count = 1;
        while (count != 10){
            if (MyInteger.isOdd(count)){
                System.out.println("True");
            }
            else {
                System.out.println("False");
            }
            count++;
        }
    }

    @org.junit.Test
    public void testIsPrime() {
        int[] primeNumber = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
        int count = 0;
        while (count <= primeNumber.length - 1){
            int value = primeNumber[count];
            if (!(MyInteger.isPrime(value))){
                System.out.print(value + " failed");
                System.exit(1);
            }
            count++;
        }
    }

    @org.junit.Test
    public void testEquals() {
    }

    @org.junit.Test
    public void parseInt() {
        char[] integer1 = {'1', '2', '3'};
        if (MyInteger.parseInt(integer1) != 123){
            System.out.println("failed");
        }
    }

    @org.junit.Test
    public void testParseInt() {
        String integer1 = "123";
        if (MyInteger.parseInt(integer1) != 123){
            System.out.println("failed");
        }
    }
}