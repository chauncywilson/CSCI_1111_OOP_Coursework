/*
Chauncy Wilson, Object-Oriented Programming 1

10/10/22, ATM Machine
 */

import java.util.Scanner;

public class ATM {
    public static void main(String[] args){
        new ATM();
    }

    int id;
    double[] account = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100};

ATM(){
    user();
    menu(id);
}

void user(){
    Scanner input = new Scanner(System.in);
    int user;
    System.out.print("Enter an ID: ");
    user = input.nextInt();
    if (user < 0 || user > 9){
        System.out.print("\nPlease enter a correct ID: ");
    }
}

void menu(int id){
    Scanner input = new Scanner(System.in);
    System.out.println("Main menu\n Check balance (1)\n Withdraw (2)\n Deposit (3) \n Exit (4)");

    int goTo = input.nextInt();

    switch (goTo){
        case 1 : checkBalance(id);
        case 2 : withdraw(id);
        case 3 : deposit(id);
        case 4 : exit();
    }
}

void checkBalance(int id){
    System.out.printf("\nYou have $%.2f\n", account[id]);
    menu(id);
}

void withdraw(int id){
    Scanner input = new Scanner(System.in);
    System.out.println("Please enter an amount to withdraw.");

    double amount = input.nextDouble();
    account[id] = Account.withdraw(account[id], amount);
    menu(id);
}

void deposit(int id){
    Scanner input = new Scanner(System.in);
    System.out.println("Please enter an amount to deposit.");

    double amount = input.nextDouble();
    account[id] = Account.deposit(account[id], amount);
    menu(id);
}

static void exit(){
    new ATM();
}
}
