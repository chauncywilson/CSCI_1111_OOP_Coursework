/*
Chauncy Wilson, Object-Oriented Programming 1

10/12/22, Super Class of Triangle
 */

import java.util.Scanner;

public class GeometricObject {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double length = input.nextDouble();
        double width = input.nextDouble();
        GeometricObject shape = new GeometricObject(length, width);
        System.out.println(shape.color() + shape.filled());
    }

    GeometricObject() {
    }

    GeometricObject(double length, double width) {
        if (!(isValid(length, width))){
            System.out.println("\nShape cannot have a negative number.");
        }
        color();
        filled();
    }

    boolean isValid(double length, double width) {
        return (length > 0 && width > 0);
    }

    String color() {
        Scanner input = new Scanner(System.in);
        System.out.print("\nEnter the color: ");
        return input.nextLine();
    }

    boolean filled() {
        Scanner input = new Scanner(System.in);
        boolean filled = false;
        System.out.print("\nIs the shape filled? Y or N: ");
        String response = input.nextLine();
        if (response.equalsIgnoreCase("Y")) {
            filled = true;
        }
        else if (!(response.equalsIgnoreCase("N"))) {
            filled();
        }
        return filled;
    }
}
