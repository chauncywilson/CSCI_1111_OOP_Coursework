/*
Chauncy Wilson, Object-Oriented Programming 1

10/13/22, Savings account subclass
 */

import java.util.Scanner;

public class SavingsAccount
    extends Account {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        new Account(1, 1000, .005);
        SavingsAccount account = new SavingsAccount(1000);

        int user = -1;
        while (user != 0) {
            System.out.printf("Your current balance is $%.2f", account.balance);
            System.out.println("\nWould you like to \n(1) Withdraw \n(2) Deposit");
            user = input.nextInt();

            if (user == 1) {
                System.out.print("Please enter an amount to withdraw. $");
                double amount = account.getAmount();
                double balance = Account.withdraw(account.balance, amount);
                if (!(account.isValidWithdraw(balance))) {
                    System.out.println("Withdraw is exceeds what is in the account.");
                    balance = 1000;
                }
                System.out.printf("\nYour current balance is $%.2f", balance);
                System.exit(0);
            }
            else if (user == 2) {
                System.out.print("\nPlease enter an amount to deposit. $");
                double amount = account.getAmount();
                double balance = Account.deposit(account.balance, amount);
                System.out.printf("Your current balance is $%.2f", balance);
                System.exit(0);
            }
            else {
                System.out.println("Incorrect input.");
            }
        }
    }

    double balance = 0;


    SavingsAccount(double newBalance) {
        getBalance(newBalance);
    }

    double getAmount() {
        Scanner input = new Scanner(System.in);
        return input.nextDouble();
    }

    double getBalance(double newBalance) {
        balance = newBalance;
        return balance;
    }

    boolean isValidWithdraw(double balance) {
        return !(balance < 0);
    }
}