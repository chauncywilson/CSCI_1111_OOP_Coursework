/*
Chauncy Wilson, Object-Oriented Programming 1

10/13/22, Checking account subclass
 */

import java.util.Date;
import java.util.Scanner;

public class CheckingAccount
    extends Account {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        new Account(1, 1000, .005);
        CheckingAccount account = new CheckingAccount(1000);
        int user = -1;
        while (user != 0) {
            System.out.println("\nWithdraw (1)\nDeposit (2)");
            user = input.nextInt();

            if (user == 1) {

                System.out.print("\nHow much would you like to withdraw? $");
                double amount = account.getAmount();
                double newBalance = Account.withdraw(1000, amount);
                if (account.isOverdraft(newBalance)) {
                    System.out.println("Overdraft limit exceeded, couldn't make withdraw.");
                    newBalance = 1000;
                }
                System.out.printf("Your current balance is $%.2f\n", newBalance);
                System.out.println(new Date());
                System.exit(0);
            }
            else if (user == 2) {
                System.out.print("\nHow much would you like to deposit? $");
                double amount = account.getAmount();
                double newBalance = Account.deposit(1000, amount);
                System.out.printf("\nYour current balance is $%.2f\n", newBalance);
                System.out.println(new Date());
                System.exit(0);
            }
            else {
                System.out.println("Incorrect input.");
            }
        }
    }

    double balance = 0;


    CheckingAccount(double newBalance) {
        getBalance(newBalance);
    }


    double getBalance(double newBalance) {
        balance = newBalance;

        System.out.printf("Your balance is: $%.2f", balance);
        return balance;
    }


    double getAmount() {
        Scanner input = new Scanner(System.in);

        return input.nextDouble();
    }


    boolean isOverdraft(double balance) {
        boolean overdraft = false;
        if (balance < 0) {
            if (balance < -50) {
                overdraft = true;
            }
        }
        return overdraft;
    }
}
