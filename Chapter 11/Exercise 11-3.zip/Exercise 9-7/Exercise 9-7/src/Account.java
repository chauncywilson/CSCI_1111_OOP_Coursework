/*
* Chauncy Wilson, Object-Oriented Programming 1
*
* Bank account, 10/4/22
*/

import java.util.Date;

public class Account {
   public static void main(String[] args) {
       //Account 1 (default)
       Account account1 = new Account();
       System.out.printf("\nAccount ID: %d\nBalance: $%.2f\nAnnual Interest Rate: %.3f\nDate Created: %s\n",
               account1.id, account1.balance, account1.annualInterestRate, account1.getDateCreated());

       System.out.println("Monthly interest rate: " + account1.getMonthlyInterestRate(account1.annualInterestRate) +
               "\nMonthly interest: " + account1.getMonthlyInterest(account1.balance, account1.annualInterestRate));

       System.out.printf("Your account after the withdraw is: $%.2f", withdraw(account1.balance,
               0.00));
       System.out.printf("\nYour account after the deposit is: $%.2f\n", deposit(account1.balance,
               0.00));

       //Account 2
       Account account2 = new Account(1122, 20000.00, .045);
       System.out.printf("\nAccount ID: %d\nBalance: $%.2f\nAnnual Interest Rate: %.3f\nDate Created: %s\n",
               account2.id, account2.balance, account2.annualInterestRate, account2.getDateCreated());

       System.out.println("Monthly interest rate: " + account1.getMonthlyInterestRate(account2.annualInterestRate) +
               "\nMonthly interest: " + account1.getMonthlyInterest(account1.balance, account2.annualInterestRate));

       System.out.printf("Your account after the withdraw is: $%.2f", withdraw(account2.balance,
               2500.00));
       System.out.printf("\nYour account after the deposit is: $%.2f", deposit(account2.balance,
               3000.00));


   }
//Data Fields
   private int id = 0;
   private double balance = 0.0;
   private double annualInterestRate = 0.0;
   Date dateCreated = new Date();

   //no-Arg Constructor
   Account(){
   }

   //constructor
   Account(int newId, double newBalance, double newAnnualInterestRate) {
       id = newId;
       balance = newBalance;
       annualInterestRate = newAnnualInterestRate;
   }

    private Date getDateCreated() {
        return dateCreated;
    }

    static double withdraw(double balance, double amount) {
       balance -= amount;
       return balance;
    }

    static double deposit(double balance, double amount) {
       balance += amount;
       return balance;
    }

    double getMonthlyInterestRate(double annualInterestRate) {
        return annualInterestRate % 12;
    }

    double getMonthlyInterest(double balance, double annualInterestRate) {
       return balance * annualInterestRate;
    }
}

